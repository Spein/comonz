 let config = {
     apiKey: "AIzaSyD2klYcbAMpTYbDvxc5XVPXeT7ppRegJzU",
     authDomain: "comonz-sandbox.firebaseapp.com",
     databaseURL: "https://comonz-sandbox-default-rtdb.firebaseio.com",
     projectId: "comonz-sandbox",
     storageBucket: "comonz-sandbox.appspot.com",
     messagingSenderId: "241744572164",
     appId: "1:241744572164:web:ab4debb703cc6ca42daa51"
 };

 let environment = "sandbox"
 export { config, environment }